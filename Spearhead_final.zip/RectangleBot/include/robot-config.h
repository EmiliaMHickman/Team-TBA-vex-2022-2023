using namespace vex;

extern brain Brain;

extern controller controller1;
extern inertial inertialSensor;
extern optical OpticalSensor;

// drive motors (green)
extern motor m1, m2, m3, m4, m5, m6;

//(blue intake motor)
extern motor intake; 
// (red roller motor)
extern motor roller;
// (red catapult motor)
extern motor catapult;

// motor groups 
extern motor_group AllRight;
extern motor_group AllLeft;
extern motor_group AllMotors;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void);
