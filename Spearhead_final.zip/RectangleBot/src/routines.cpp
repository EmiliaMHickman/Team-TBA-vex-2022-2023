#include "routines.h"
#include "autonomous.h"

void moveinbox()
{
  //moveForward(20, 100, 10);
  //AutoRoller(50, 10);
  inertialTurn(20, 100, 90, 1);
}