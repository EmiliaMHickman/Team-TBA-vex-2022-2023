#include "vex.h"
#include "robot-config.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

controller controller1(primary);

// Right motor group
motor m1 (PORT20, ratio18_1, false);
motor m2 (PORT19, ratio18_1, false);
motor m3 (PORT18, ratio18_1, false);


// Left motor group
motor m4 (PORT17, ratio18_1, true);
motor m5 (PORT16, ratio18_1, true);
motor m6 (PORT15, ratio18_1, true);

// motor functions
motor intake(PORT13, ratio36_1, true); 
motor roller(PORT11, ratio18_1, true);
motor catapult(PORT12, ratio36_1, true);

// inertial sensors
inertial inertialLeft(PORT1);
inertial inertialRight(PORT2);
inertial inertialSensor(PORT9);

// Optical sensor
optical OpticalSensor(PORT11);


// motor grouping
motor_group AllLeft (m4, m5, m6);
motor_group AllRight (m1, m2, m3);

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */
void vexcodeInit(void) {
  // Nothing to initialize
}