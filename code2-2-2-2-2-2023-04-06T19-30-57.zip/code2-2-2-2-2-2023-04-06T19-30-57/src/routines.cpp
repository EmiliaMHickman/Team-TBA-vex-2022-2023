#include "vex.h"
#include "routines.h"
#include "autonomous.h"
#include "driving-functions.h"

//void moveinbox()

  //moveForward(20, 100, 10);
  //AutoRoller(50, 10);
  //inertialTurn(20, 100, 90, 1);
  


/*-------------------------------------------------------------------|
Comments for First routine (only turning rollers(turning clockwise)) |
---------------------------------------------------------------------*/
//Took out the other autons, DON'T FORGET TO PUT THEM BACK; also, change moveinbox code to the new one

/*void Rollerandshoot()// if everything works use this one
{
  moveForward(40, 50, 10);
  wait(500, msec);
  TurninPlace(14, 60, 10);
  wait(500, msec);
  moveForward(6, 50, 10);
  wait(500, msec);
  moveForward(-6, 50, 10);
  wait(500, msec);
  TurninPlace(-13, 50, 10);
  wait(500, msec);
  moveForward(-150, 50, 10);
  wait(500, msec);
  TurninPlace(14, 50, 10);
  wait(500, msec);
  moveForward(-158, 50, 10);
  wait(500, msec);
  TurninPlace(13, 50, 10);
  wait(500, msec);
  moveForward(6, 50, 10);
  wait(500,msec);
  moveForward(-8, 50, 10);
  wait(500, msec);//
  TurninPlace(6, 60, 10);
  wait(500, msec);
  moveForward(-95, 50, 10);
  wait(500, msec);
  TurninPlace(-13, 50, 10);// maybe 12
  wait(500, msec);
  //moveForward(-11, 50, 10);//do  12, might have to get rid of this
  wait(500, msec);
  catapultauto(1000, 2);

}*/


 void twoRollersBlue()// this is for blue side 
 {
   
 moveForward(7, 20, 10);
 wait(500, msec);
 checkRoller(blue); // will change it to blue
 wait(500, msec);
 moveForward(-5, 50, 10);
 wait(500, msec);
 TurninPlace(14, 30, 10);
 wait(500, msec);
 moveForward(-146, 60, 10);
 wait(500, msec);
 TurninPlace(-14, 30, 10);
 wait(500, msec);
 moveForward(-152, 60, 10);
 wait(500, msec);
 TurninPlace(-14, 30, 10);
 wait(500, msec);
 moveForward(10, 20, 10);
 wait(500, msec);
 checkRoller(blue);//will turn roller to blue
 wait(500, msec);
 moveForward(-90, 60, 10);
 wait(500, msec);
 TurninPlace(13, 30, 10);
 wait(500, msec);
 moveForward(-10, 60, 10);
 wait(500, msec);
 TurninPlace(-13, 30, 10);
 wait(500, msec);
 moveForward(-11, 60, 10);
 wait(500, msec);
 TurninPlace(-5, 30, 10);
 catapultauto(1000, 2);
 wait(500, msec);
 TurninPlace(5, 30, 10);
 moveForward(11, 60, 10);


 }

/*
  move forward, in front of color thing on the floor  
  turn 90* 
  move forward, towards/ in front of the disk intake thing
  turn -90*
  wait for disk to be intaked
  move forward 
  turn 45*
  shoot 
  turn -45* 
  move backwards, to the disk intake thing
  repeat  steps 5 - 10 on a loop(7)
*/

 /*void twoRollers()
 {
 moveForward(6, 20, 10);
 wait(500, msec);
 checkRoller(red); // will change it to red 
 wait(500, msec);
 moveForward(-6, 50, 10);
 wait(500, msec);
 TurninPlace(14, 30, 10);
 wait(500, msec);
 moveForward(-155, 60, 10);
 wait(500, msec);
 TurninPlace(-14, 30, 10);
 wait(500, msec);
 moveForward(-148, 60, 10);
 wait(500, msec);
 TurninPlace(-14, 30, 10);
 wait(500, msec);
 moveForward(6, 20, 10);
 wait(500, msec);
 checkRoller(red); //will turn roller to red
 }*/