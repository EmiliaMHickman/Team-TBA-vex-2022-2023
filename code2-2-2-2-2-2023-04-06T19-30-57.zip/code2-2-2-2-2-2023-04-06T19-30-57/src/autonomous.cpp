#include "vex.h"
#include "autonomous.h"
using namespace vex;

/*------------------------
| FUNCTIONS FOR ROUTINES |
------------------------*/

void SetTimeout(int seconds) //  wait function - test might use instead of wait func/ ALSO USED FOR 
{
  AllLeft.setTimeout(seconds, sec);
  AllRight.setTimeout(seconds, sec);
}

void moveForward(int dist, int speed, int timeout) // MOVES BOT FW AND BW, FW IS NEGATIVE AND BW IS POSITIVE
{
  SetTimeout(timeout); // THIS IS A WAIT FUNC
  AllLeft.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);
  SetTimeout(0);
}

void TurninPlace(int dist, int speed, int timeout) //a postitve number will turn right, a negative number will turn left//
{
  SetTimeout(timeout);
  AllLeft.spinFor(reverse, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);
  SetTimeout(0);

}

double kP = 0.0;
double kI = 0.0;
double kD = 0.0;
double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;
int maxTurnIntegral = 300; // These cap the integrals
int maxIntegral = 300;
int integralBound = 3; //If error is outside the bounds, then apply the integral. This is a buffer with +-integralBound degrees

//Autonomous Settings
int desiredValue = 200;
int desiredTurnValue = 0;

int error; //SensorValue - DesiredValue : Position
int prevError = 0; //Position 20 miliseconds ago
int derivative; // error - prevError : Speed
int totalError = 0; //totalError = totalError + error

int turnError; //SensorValue - DesiredValue : Position
int turnPrevError = 0; //Position 20 miliseconds ago
int turnDerivative; // error - prevError : Speed
int turnTotalError = 0; //totalError = totalError + error

double signnum_c(double x) {
  if (x > 0.0) return 1.0;
  if (x < 0.0) return -1.0;
  return x;
}

void movestraightPID(int speed, int dist)
{
  AllLeft.spin(forward, speed, pct);
  AllRight.spin(forward, speed, pct);
  
  m3.resetPosition();
  m5.resetPosition();
  int xposition = 0; //need to figure out what this is or will create infinite loop

  while (xposition < dist)
  {
    int leftMotorPosition = m3.position(degrees);
    int rightMotorPosition = m5.position(degrees);
    printf("%d", rightMotorPosition);
    printf("%d ", leftMotorPosition);
    printf("\n");
    ///////////////////////////////////////////
    //Lateral movement PID
    ///////////////////////////////////////////
    //Get average of the two motors

    int averagePosition = (leftMotorPosition + rightMotorPosition)/2;

    //Potential
    error = averagePosition - speed;

    //Derivative
    derivative = error - prevError;

    //Integral
    if(abs(error) < integralBound){
    totalError+=error; 
    }  else {
    totalError = 0; 
    }
    //totalError += error;

    //This would cap the integral
    totalError = abs(totalError) > maxIntegral ? signnum_c(totalError) * maxIntegral : totalError;

    double lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    
    AllLeft.spin(forward, lateralMotorPower, pct);
    AllRight.spin(forward, lateralMotorPower, pct);
  }
    AllLeft.stop();
    AllRight.stop();
}
void TurninPlacePID(int dist, int speed, int timeout)
{
  AllLeft.spinFor(reverse, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);

  m3.resetPosition();
  m5.resetPosition();

}

void catapultauto(int dist, int timeout)
{
   SetTimeout(timeout);
   catapult.spinFor(reverse, dist, degrees);
   SetTimeout(0);
}

/*void AutoRoller(int dist, int timeout) //get rid of this
{
  SetTimeout(timeout);
  roller.spinFor(forward, double (dist), rev, double (2000), rpm, true);
  SetTimeout(5000);
}*/

 void checkRoller(vex::color desiredColor) 
 {

  OpticalSensor.setLightPower(100, pct);// itk this is the light, if so set to 0 then testing, 100
  while (!OpticalSensor.isNearObject())
  { printf("TEST!@: %i", OpticalSensor.isNearObject());
    AllRight.spin(reverse, 5, pct);
    AllLeft.spin(reverse, 5, pct);
  } 

  AllRight.stop();
  AllLeft.stop();
  //checks if sensor is near roller
  do // is going to do 
  {
      roller.spin(fwd, 30, pct); //fwd is going to spin intake roller if the top statement is true
  }
  while (OpticalSensor.color() != desiredColor); // while the 2nd statement is true it is going to changes to opposite color, blue = red, red = blue
  
  roller.stop();// this will stop the roller if the if statement is true and has changed correctly to the opposite color 
  OpticalSensor.setLightPower(0, pct);

}
/* void checkRollerBlue()
{
  

  OpticalSensor.setLightPower(100, pct);// itk this is the light, if so set to 0 then testing, 100
  if(OpticalSensor.isNearObject())//checks if sensor is near roller
  { 
    do // is going to do 
    {
        roller.spin(fwd, 60, pct); //fwd is going to spin intake roller if the top statement is true, itk its suppose to be roller
    }
    while (OpticalSensor.color() == red); // while the 2nd statement is true it is going to changes to opposite color
    
      roller.stop(); // will stop this command if it has changed correctly to the opposite color  itk its suppose to be roller
 }

}*/


double inertialAVG()
{
  double sum = 0;
  sum = (fabs(inertialSensor.rotation(degrees)));
  return sum;
}

void inertialTurn(double dist, double speed, double degrees, double timeout)
{
  inertialSensor.setRotation(0, deg);

  if(dist < 0){
    while(inertialAVG() < degrees){
      AllLeft.spin(fwd, speed, pct);
      AllRight.spin(reverse, speed, pct);
    }
    do{
      AllLeft.spin(reverse, 10, pct);
      AllRight.spin(fwd, 10, pct);
    }while(inertialAVG() > degrees);
  }else if(dist > 0){
    while(inertialAVG() < degrees){
      AllLeft.spin(reverse, speed, pct);
      AllRight.spin(fwd, speed, pct);
    }
    do{
      AllLeft.spin(fwd, 10, pct);
      AllRight.spin(reverse, 10 , pct);
    }while(inertialAVG() > degrees);
  }
  AllLeft.stop(hold);
  AllRight.stop(hold);
}


