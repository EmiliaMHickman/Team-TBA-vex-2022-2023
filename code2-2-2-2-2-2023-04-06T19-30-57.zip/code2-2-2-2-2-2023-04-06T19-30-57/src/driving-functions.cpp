#include "driving-functions.h"
#include "vex.h"
#include "robot-config.h"
using namespace vex;

void tankdrive()
{
  if (abs(controller1.Axis3.value()) > 5 || abs(controller1.Axis2.value()) > 5) //1=2, 2=3left side is Axis 3, right side is Axis 2
  {
    AllLeft.spin(reverse, (controller1.Axis3.value()), pct); // 2if left Axis(3) is moved fw or bw it wiil run the wheels< reverse
    AllRight.spin(reverse, (controller1.Axis2.value()), pct); // 3if right Axis(2) is moved fw or bw it wiil run the wheels< reverse
  }
  else
  {
    AllRight.stop(coast); 
    AllLeft.stop(coast);
  }
} 

bool Toggle = false;  // if it's not pressed
bool ToggleSwitch = false; // if it's not pressed

void Intake()
{
  if (controller1.ButtonR1.pressing()) // right top back button
  {
    if (!ToggleSwitch)
    {
      ToggleSwitch = true; // if it's pressed 
      Toggle = !Toggle;
      if (Toggle) //  if it's pressed
      {
        intake.spin(reverse,100,pct); // will spin intake wheels 
      }
      else 
      {
        intake.stop(); // stops intake wheels when button is pressed a 2nd time
      }
    }
  }
  else 
  {
    ToggleSwitch = false; // stops code
  }
}

void Roller()
{
  if (controller1.ButtonL1.pressing()) // if button is being pressed it will do the following 
  {
     roller.spin(forward, 100, pct);  // will spin roller wheel 
  }
  else // else if button is pressed a 2nd time it will do the following
  {
    roller.stop(); // stops code
  }
}
void Thrower() 
{
  if (controller1.ButtonL2.pressing()) // if button L2(back bottom button) being presssed it will do the following
  {
    catapult.spin(reverse, 100, pct); // will spin catapult back and forth <- make this into to a back one the fornt two/ like a one two thing not just one and go
  }
  else
  {
    catapult.stop(); // else when top function is complete this will stop code 
  }
}
/*
bool intaking = false;
bool catapultWind = true;
long int prevValue = -1;

void catapultLogic() 
{
  if (catapultWind)
  {
    windUp();// figure out what this would be in your code
  }
  controller1.ButtonL2.pressed(Thrower); // add the void shoot disk
 
}
void windUp() {

  if (catapultBumper.value() == prevValue)// figure out what this would be in your code
  {
    catapult.spin(reverse, 100, pct);
  } else {
    catapultWind = !catapultWind;
    catapult.stop();
  }
}
void shootDisks() 
{
  catapult.setTimeout(1200, msec);
  catapult.spinFor(reverse, 1200, msec);
  catapult.setTimeout(0, msec);
  catapultWind = true;
  prevValue = catapultBumper.value();// figure out what this would be in your code
}*/

/*-------------------------------------
| DO NOT TOUCH!! EMI IS TESTING THIS! |
-------------------------------------*/
/*void OpticalRoller() //rid of this
{
  OpticalSensor.setLightPower(100, pct);
  if(OpticalSensor.isNearObject())//&& controller1.ButtonL1.pressing())
  {
    while (OpticalSensor.color() == blue)
    {
      intake.spin(forward, 100, pct);
    }
      intake.stop();
    }
}*/




