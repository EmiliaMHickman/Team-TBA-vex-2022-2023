#ifndef DRIVING_FUNCTIONS
#define DRIVING_FUNCTIONS

void tankdrive();
void Intake();
void Roller();
void Thrower();
//void OpticalRoller();
#endif