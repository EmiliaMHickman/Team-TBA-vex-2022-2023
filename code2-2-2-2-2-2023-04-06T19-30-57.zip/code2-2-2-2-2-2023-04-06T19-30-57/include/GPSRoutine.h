#ifndef GPSROUTINE
#define GPSROUTINE

//void score130points();

void middleScore();





#endif