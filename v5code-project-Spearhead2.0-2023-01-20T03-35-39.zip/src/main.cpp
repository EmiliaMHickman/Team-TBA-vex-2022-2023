/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Leo Zubiate                                               */
/*    Created:      Fri Oct 07 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "driving-functions.h"
#include "robot-config.h"
#include "routines.h"
#include "GPSRoutine.h"
using namespace vex;

competition Competition;

void usercontrol()
{
  while (1)
  {
    tankdrive();
    Intake();
    Roller();
    Thrower();
    OpticalRoller();
  }
}

void Autonomous()
{ 
  moveinbox();
  //middleScore();
 
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
   Competition.drivercontrol(usercontrol);
  Competition.autonomous(Autonomous);
}
