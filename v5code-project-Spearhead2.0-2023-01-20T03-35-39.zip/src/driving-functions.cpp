#include "driving-functions.h"
#include "vex.h"
#include "robot-config.h"
using namespace vex;

void tankdrive()
{
  if (abs(controller1.Axis2.value()) > 5 || abs(controller1.Axis3.value()) > 5)
  {
    AllLeft.spin(reverse, (controller1.Axis2.value()), pct);
    AllRight.spin(reverse, (controller1.Axis3.value()), pct); 
  }
  else
  {
    AllRight.stop(coast);
    AllLeft.stop(coast);
  }
} 

bool Toggle = false;
bool ToggleSwitch = false;

void Intake()
{
  if (controller1.ButtonR1.pressing())
  {
    if (!ToggleSwitch)
    {
      ToggleSwitch = true;
      Toggle = !Toggle;
      if (Toggle)
      {
        intake.spin(reverse,100,pct);
      }
      else 
      {
        intake.stop();
      }
    }
  }
  else 
  {
    ToggleSwitch = false;
  }
}

void Roller()
{
  if (controller1.ButtonL1.pressing())
  {
     roller.spin(forward, 100, pct);
  }
  else 
  {
    roller.stop();
  }
}

void Thrower()
{
  if (controller1.ButtonL2.pressing())
  {
    catapult.spin(reverse, 100, pct);
  }
  else
  {
    catapult.stop();
  }
}

void OpticalRoller()
{
  OpticalSensor.setLightPower(100, pct);
  if(OpticalSensor.isNearObject())
  {
    while (OpticalSensor.color() == blue)
    {
      intake.spin(forward, 100, pct);
    }
      intake.stop();
    }
}


