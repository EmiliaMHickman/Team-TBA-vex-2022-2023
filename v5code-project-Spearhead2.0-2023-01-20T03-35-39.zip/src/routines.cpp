#include "vex.h"
#include "routines.h"
#include "autonomous.h"
#include "driving-functions.h"

//void moveinbox()

  //moveForward(20, 100, 10);
  //AutoRoller(50, 10);
  //inertialTurn(20, 100, 90, 1);
  


/*-------------------------------------------------------------------|
Comments for First routine (only turning rollers(turning clockwise)) |
---------------------------------------------------------------------*/
/*void moveinbox()//blue
{
// movebackwards 3cm, negitive is forward and positive is backward (diynig..)
TurninPlace(-12, -50, 10);
wait(500, msec);
moveForward(-50, -60, 10);
wait(500, msec);
TurninPlace(12, 50, 10);
wait(500, msec);
moveForward( 9, 60, 10);
wait(500, msec);
// spin roller (full power)
AutoRoller(2, 6); // to long, shorten rolling time and speed
// wait (500 msec) (taking to long :( )
wait(500, msec);
}*/

/*oid moveinbox()//red: use on blue until blues is fixed//make another blue auton
{
  TurninPlace(-12, -50, 10);
wait(500, msec);
moveForward(-55, -60, 10); //55 if you are on red, 50 for blue
wait(500, msec);
TurninPlace(12, 50, 10); 
wait(500, msec);
//moveForward(11, 60, 10); // make sure this is not to much/ not going to get stuck under the roller, 11 for red, 10-9 for blue
// spin roller (full power)
///AutoRoller(2, 6); // if the roller is split half way colors, do 1, if full color on the top do 2-3 <- test this before asuming this
// wait (500 msec) (taking to long :( )
//wait(500, msec);
}*/





/*void moveinbox()// Skills for blue side |
{
  TurninPlace(-12, -50, 10);
wait(500, msec);
moveForward(-55, -60, 10);
wait(500, msec);
TurninPlace(12, 50, 10);
wait(500, msec);
moveForward(11, 60, 10);
// spin roller (full power)
AutoRoller(2, 6); // to long, shorten rolling time and speed
// wait (500 msec) (taking to long :( )
wait(500, msec);
//move forward (one square)
moveForward( -35, -75, -10 );
// wait (500 msec)
wait(500, msec);
// turn clocckwise (180* degrees) (celcius is better)
TurninPlace(-12, 50, 10);
// wait (500, msec)
wait(500, msec);
// move backward (2 feet <- change to cm) (that's so tall :( )
moveForward(38, 60, 10);
// wait (500, msec)
wait(500, msec);
// spin roller (full power)
AutoRoller(2, 10);
wait (200, msec);

}*/
  


/*void moveinbox()
{
  TurninPlace(-12,-50, 10);
wait(500, msec);
moveForward(-50, -60, 10);
wait(500, msec);
TurninPlace(12, 50, 10);
wait(500, msec);
moveForward(9, 60, 10);
wait(500, msec);
// spin roller (full power)
AutoRoller(-2, 6); // to long, shorten rolling time and speed
// wait (500 msec) (taking to long :( )
wait(500, msec);
moveForward( -35, -75, -10 );
// wait (500 msec)
wait(500, msec);
// turn clocckwise (180* degrees) (celcius is better)
TurninPlace(10, 50, 10);
// wait (500, msec)
wait(500, msec);
// move backward (2 feet <- change to cm) (that's so tall :( )
moveForward(38, 60, 10);
// wait (500, msec)
wait(500, msec);
// spin roller (full power)
AutoRoller(-2, 10);
wait (200, msec);
}*/

//move forward (one square)
//moveForward( -35, -75, -10 );
// wait (500 msec)
//wait(500, msec);
// turn clocckwise (180* degrees) (celcius is better)
//TurninPlace(-12, 50, 10);
// wait (500, msec)
//wait(500, msec);
// move backward (2 feet <- change to cm) (that's so tall :( )
//moveForward(38, 60, 10);
// wait (500, msec)
//wait(500, msec);
// spin roller (full power)
//AutoRoller(2, 10);
//wait (200, msec);
//vex::wait(1000, msec);
// turn u End routine


//move forward (one square)
//moveForward( -35, -75, -10 );
// wait (500 msec)
//wait(500, msec);
// turn clocckwise (180* degrees) (celcius is better)
//TurninPlace(-12, 50, 10);
// wait (500, msec)
//wait(500, msec);
// move backward (2 feet <- change to cm) (that's so tall :( )
//moveForward(38, 60, 10);
// wait (500, msec)
//wait(500, msec);
// spin roller (full power)
//AutoRoller(2, 10);
//wait (200, msec);
//vex::wait(1000, msec);
// turn u End routine



















//move forward (one square)
//moveForward( -35, -75, -10 );
// wait (500 msec)
//wait(500, msec);
// turn clocckwise (180* degrees) (celcius is better)
//TurninPlace(-12, 50, 10);
// wait (500, msec)
//wait(500, msec);
// move backward (2 feet <- change to cm) (that's so tall :( )
//moveForward(38, 60, 10);
// wait (500, msec)
//wait(500, msec);
// spin roller (full power)
//AutoRoller(2, 10);
//wait (200, msec);
//vex::wait(1000, msec);
// turn u End routine

//}*/


// Same as first one just counterclockwise <- have better comments later 
//void movenbox()
//{
// movebackwards 3cm, negitive is forward and positive is backward 
//moveForward( 2, 31, 10 ); // test this, for after driver mode if to far or to close to roller
// wait (500, msec)
//wait(500, msec);
// spin roller (full power)
//AutoRoller(2, 10); // fixed
// wait (500 msec) 
//wait(500, msec);
//move forward (one square)
//moveForward( -35, -75, -10 );
// wait (500 msec)
//wait(500, msec);
// turn clocckwise (180* degrees) 
//TurninPlace(12, 50, 10);
// wait (500, msec)
//wait(500, msec);
// move backward (2 feet <- change to cm) 
//moveForward(38, 60, 10);
// wait (500, msec)
//wait(500, msec);
// spin roller (full power)
//AutoRoller(2, 10);
// wait (500, msec)
//wait (200, msec);
//vex::wait(1000, msec);
// turn u End routine

//}


///void moveinshoot()

  
/*void moveinbox()//blue 1.0 blue roller -
{
// movebackwards 3cm, negitive is forward and positive is backward (diynig..)
TurninPlace(12, 50, 10);
wait(500, msec);
moveForward(-50, -60, 10);
wait(500, msec);
TurninPlace(-12, -50, 10);
wait(500, msec);
moveForward( 9, 60, 10);
wait(500, msec);
// spin roller (full power)
AutoRoller(2, 6); // to long, shorten rolling time and speed
// wait (500 msec) (taking to long :( )
wait(500, msec);
}*/