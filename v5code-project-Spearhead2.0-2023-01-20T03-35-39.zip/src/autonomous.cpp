#include "vex.h"
#include "autonomous.h"
using namespace vex;

void SetTimeout(int seconds)
{
  AllLeft.setTimeout(seconds, sec);
  AllRight.setTimeout(seconds, sec);
}

void moveForward(int dist, int speed, int timeout)
{
  SetTimeout(timeout);
  AllLeft.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);
  SetTimeout(0);
}

void TurninPlace(int dist, int speed, int timeout) //a postitve number will turn right, a negative number will turn left//
{
  SetTimeout(timeout);
  AllLeft.spinFor(reverse, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);
  SetTimeout(0);

}

double kP = 0.0;
double kI = 0.0;
double kD = 0.0;
double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;
int maxTurnIntegral = 300; // These cap the integrals
int maxIntegral = 300;
int integralBound = 3; //If error is outside the bounds, then apply the integral. This is a buffer with +-integralBound degrees

//Autonomous Settings
int desiredValue = 200;
int desiredTurnValue = 0;

int error; //SensorValue - DesiredValue : Position
int prevError = 0; //Position 20 miliseconds ago
int derivative; // error - prevError : Speed
int totalError = 0; //totalError = totalError + error

int turnError; //SensorValue - DesiredValue : Position
int turnPrevError = 0; //Position 20 miliseconds ago
int turnDerivative; // error - prevError : Speed
int turnTotalError = 0; //totalError = totalError + error

double signnum_c(double x) {
  if (x > 0.0) return 1.0;
  if (x < 0.0) return -1.0;
  return x;
}

void movestraightPID(int speed, int dist)
{
  AllLeft.spin(forward, speed, pct);
  AllRight.spin(forward, speed, pct);
  
  m3.resetPosition();
  m5.resetPosition();
  int xposition = 0; //need to figure out what this is or will create infinite loop

  while (xposition < dist)
  {
    int leftMotorPosition = m3.position(degrees);
    int rightMotorPosition = m5.position(degrees);
    printf("%d", rightMotorPosition);
    printf("%d ", leftMotorPosition);
    printf("\n");
    ///////////////////////////////////////////
    //Lateral movement PID
    ///////////////////////////////////////////
    //Get average of the two motors

    int averagePosition = (leftMotorPosition + rightMotorPosition)/2;

    //Potential
    error = averagePosition - speed;

    //Derivative
    derivative = error - prevError;

    //Integral
    if(abs(error) < integralBound){
    totalError+=error; 
    }  else {
    totalError = 0; 
    }
    //totalError += error;

    //This would cap the integral
    totalError = abs(totalError) > maxIntegral ? signnum_c(totalError) * maxIntegral : totalError;

    double lateralMotorPower = error * kP + derivative * kD + totalError * kI;
    
    AllLeft.spin(forward, lateralMotorPower, pct);
    AllRight.spin(forward, lateralMotorPower, pct);
  }
    AllLeft.stop();
    AllRight.stop();
}
void TurninPlacePID(int dist, int speed, int timeout)
{
  AllLeft.spinFor(reverse, double (dist/(8.225*M_PI)), rev, double (speed), rpm, false);
  AllRight.spinFor(forward, double (dist/(8.225*M_PI)), rev, double (speed), rpm, true);

  m3.resetPosition();
  m5.resetPosition();

}

void catapultauto(int dist)
{
  catapult.spinFor(reverse, dist, degrees);
}

void AutoRoller(int dist, int timeout)
{
  SetTimeout(timeout);
  roller.spinFor(forward, double (dist), rev, double (2000), rpm, true);
  SetTimeout(5000);
}

double inertialAVG()
{
  double sum = 0;
  sum = (fabs(inertialSensor.rotation(degrees)));
  return sum;
}

void inertialTurn(double dist, double speed, double degrees, double timeout)
{
  inertialSensor.setRotation(0, deg);

  if(dist < 0){
    while(inertialAVG() < degrees){
      AllLeft.spin(fwd, speed, pct);
      AllRight.spin(reverse, speed, pct);
    }
    do{
      AllLeft.spin(reverse, 10, pct);
      AllRight.spin(fwd, 10, pct);
    }while(inertialAVG() > degrees);
  }else if(dist > 0){
    while(inertialAVG() < degrees){
      AllLeft.spin(reverse, speed, pct);
      AllRight.spin(fwd, speed, pct);
    }
    do{
      AllLeft.spin(fwd, 10, pct);
      AllRight.spin(reverse, 10 , pct);
    }while(inertialAVG() > degrees);
  }
  AllLeft.stop(hold);
  AllRight.stop(hold);
}