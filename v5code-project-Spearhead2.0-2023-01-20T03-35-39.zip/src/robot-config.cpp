#include "vex.h"
#include "robot-config.h"

using namespace vex;

// A global instance of brain used for printing to the V5 brain screen
brain Brain;

controller controller1(primary);

// Right motor group
motor m1 (PORT20, ratio18_1, false);
motor m2 (PORT19, ratio18_1, false);
motor m3 (PORT18, ratio18_1, false);


// Left motor group
motor m4 (PORT17, ratio18_1, true);
motor m5 (PORT16, ratio18_1, true);
motor m6 (PORT15, ratio18_1, true);

// motor functions
motor intake(PORT9, ratio36_1, true); 
motor roller(PORT13, ratio18_1, true);
motor catapult(PORT12, ratio36_1, true);

// inertial sensors
inertial inertialLeft(PORT1);
inertial inertialRight(PORT2);
inertial inertialSensor(PORT9);

// Optical sensor
optical OpticalSensor(PORT11);


// motor grouping
motor_group AllLeft (m4, m5, m6);
motor_group AllRight (m1, m2, m3);

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 *
 * This should be called at the start of your int main function.
 */

//GPS
gps DrivetrainGPS = gps(PORT11, -125, -37.5, mm, -90); //port, x, y, units, angle
smartdrive Drivetrain = smartdrive(AllLeft, AllRight, DrivetrainGPS, 319.19, 320, 40, mm, 1);
long map(long x, long in_min, long in_max, long out_min, long out_max)
 {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void vexcodeInit(void) {
  Brain.setTimer(0, msec);
  Brain.Screen.print("Device initialization...");
  Brain.Screen.setCursor(2, 1);
  // calibrate the drivetrain GPS
  wait(200, msec);
  DrivetrainGPS.calibrate();
  Brain.Screen.print("Calibrating GPS for Drivetrain");
  // wait for the GPS calibration process to finish
  while (DrivetrainGPS.isCalibrating()) {
    wait(25, msec);
  }

  //Set Drivetrain Velocity
  Drivetrain.setHeading(DrivetrainGPS.heading(), degrees);

  // reset the screen now that the calibration is complete
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1,1);
  wait(50, msec);
  Brain.Screen.clearScreen();
}