#ifndef AUTONOMOUS
#define AUTONOMOUS


void SetTimeout(int);
void vex::wait(double time, timeUnits units);
void moveForward(int dist, int speed, int seconds); //(int dist, int speed, int timeout(seconds))//
void TurninPlace(int dist, int speed, int seconds); //(int dist, int speed, int timeout(seconds))//
void IntakeSpitAuto(int dist, int speed, int timeout);
void movestraightPID(int speed, int dist);
void catapultauto(int dist);
void TurninPlacePID(int dist, int speed, int timeout);
void AutoRoller(int dist, int timeout);
void inertialTurn(double dist, double speed, double degrees, double timeout);
double inertialAVG();
#endif